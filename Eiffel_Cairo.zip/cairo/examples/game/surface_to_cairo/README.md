The tower.png image is from Firkin and licensed CC0: https://openclipart.org/detail/277699/eiffel-tower-2
