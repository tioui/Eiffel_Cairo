Every examples are licensed GPL Version 3 (see: LICENSE.md).
